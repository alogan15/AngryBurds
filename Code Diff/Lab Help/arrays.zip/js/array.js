const planets = [ 
  'Mercury', 
  'Venus', 
  'Earth', 
  'Mars'
];

console.log( planets[0] );
console.log( planets[3] );
console.log( planets[2] );
console.log( planets[4] );